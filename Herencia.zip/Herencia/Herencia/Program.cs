﻿using System;

class Program
{
    static void Main(string[] args)
    {
        Carro carro1 = new Carro
        {
            Marca = "Toyota",
            Modelo = "Corolla",
            Año = 2020,
            NumeroPuertas = 4,
            TipoCombustible = "Gasolina"
        };

        Carro carro2 = new Carro
        {
            Marca = "Tesla",
            Modelo = "Model 3",
            Año = 2023,
            NumeroPuertas = 4,
            TipoCombustible = "Eléctrico"
        };

        Moto moto1 = new Moto
        {
            Marca = "Yamaha",
            Modelo = "FZ25",
            Año = 2021,
            Cilindrada = 250,
            TieneMaletero = false
        };

        Moto moto2 = new Moto
        {
            Marca = "Honda",
            Modelo = "PCX",
            Año = 2022,
            Cilindrada = 160,
            TieneMaletero = true
        };

        carro1.MostrarInformacion();
        carro2.MostrarInformacion();
        moto1.MostrarInformacion();
        moto2.MostrarInformacion();

        Console.ReadKey();
    }
}