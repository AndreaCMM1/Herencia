﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

public class Moto : Vehiculo
{
    public int Cilindrada { get; set; }
    public bool TieneMaletero { get; set; }

    public override void MostrarInformacion()
    {
        Console.WriteLine("===== MOTO =====");
        base.MostrarInformacion();
        Console.WriteLine($"Cilindrada: {Cilindrada} cc");
        Console.WriteLine($"Tiene maletero: {(TieneMaletero ? "Si" : "No")}");
        Console.WriteLine();
    }
}