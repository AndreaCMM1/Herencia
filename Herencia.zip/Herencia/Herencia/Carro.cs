﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

public class Carro : Vehiculo
{
    public int NumeroPuertas { get; set; }
    public string TipoCombustible { get; set; } = "";

    public override void MostrarInformacion()
    {
        Console.WriteLine("===== CARRO =====");
        base.MostrarInformacion();
        Console.WriteLine($"Número de puertas: {NumeroPuertas}");
        Console.WriteLine($"Tipo de combustible: {TipoCombustible}");
        Console.WriteLine();
    }
}